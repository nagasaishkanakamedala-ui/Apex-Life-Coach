// pages/api/dining.js
// Server-side proxy for Nutrislice / OSU Dining menus (no CORS issues)

const HALLS = {
  morrill: 'traditions-at-morrill',
  scott:   'traditions-at-scott',
  kennedy: 'traditions-at-kennedy',
  curl:    'curl-market',
  neil:    'marketplace-on-neil',
  woodys:  'woodys',
  sloopys: 'sloopys-diner',
  union:   'union-market',
  berry:   'berry-cafe',
};

export default async function handler(req, res) {
  const { hall, meal, date } = req.query;
  const slug = HALLS[hall];

  if (!slug) {
    return res.status(400).json({ error: `Unknown hall: ${hall}. Valid: ${Object.keys(HALLS).join(', ')}` });
  }

  const today    = date || new Date().toISOString().split('T')[0];
  const mealType = meal || 'lunch';
  const url      = `https://osu.nutrislice.com/menu/api/weeks/school/${slug}/menu-type/${mealType}/${today}/`;

  try {
    const r = await fetch(url, {
      headers: {
        Accept:       'application/json',
        'User-Agent': 'Mozilla/5.0 APEX-Coach/1.0',
      },
    });

    if (!r.ok) {
      return res.status(r.status).json({ error: `Nutrislice ${r.status} for ${slug}` });
    }

    const data = await r.json();
    const items = [];
    const seen  = new Set();

    for (const day of (data?.days || [])) {
      if (day.date !== today) continue;
      for (const entry of (day.menu_items || [])) {
        const food = entry?.food;
        if (!food?.name || seen.has(food.name)) continue;
        seen.add(food.name);
        const n = food.nutrients || {};
        items.push({
          name:    food.name,
          cal:     Math.round(n.calories || n.Calories || 0),
          prot:    parseFloat((n.protein || n.Protein || 0).toFixed(1)),
          carb:    parseFloat((n.total_carbohydrates || n.Carbohydrate || 0).toFixed(1)),
          fat:     parseFloat((n.total_fat || n.Fat || 0).toFixed(1)),
          fiber:   parseFloat((n.dietary_fiber || 0).toFixed(1)),
          sodium:  Math.round(n.sodium || 0),
          serving: food.serving_size_info
            ? `${food.serving_size_info.serving_size_amount || ''} ${food.serving_size_info.serving_size_unit || ''}`.trim()
            : null,
          veg:   (food.icons || []).some(i => typeof i === 'string' && /veg/i.test(i)),
          vegan: (food.icons || []).some(i => typeof i === 'string' && /vegan/i.test(i)),
          icons: food.icons || [],
        });
      }
    }

    // Cache for 30 minutes
    res.setHeader('Cache-Control', 's-maxage=1800, stale-while-revalidate=3600');
    return res.status(200).json({ hall: slug, meal: mealType, date: today, count: items.length, items });

  } catch (err) {
    console.error('Dining proxy error:', err);
    return res.status(500).json({ error: err.message });
  }
}
