# APEX Life Coach — Deploy Guide

## What's in this repo

- `/pages/api/whoop/` — WHOOP OAuth login, callback, data fetch, disconnect
- `/pages/api/canvas/` — Canvas LMS proxy (saves token in cookie)
- `/pages/api/dining.js` — OSU Dining / Nutrislice proxy (no CORS issues)
- `/pages/api/ai.js` — Claude AI proxy (keeps your API key server-side)
- `/pages/index.html` — Full APEX dashboard frontend

---

## Deploy in 10 minutes

### Step 1 — Push to GitHub

1. Go to **github.com** → New Repository → name it `apex-coach` → Private → Create
2. On your computer, open Terminal (Mac) or Command Prompt (Windows)
3. Run these commands:

```bash
cd ~/Downloads
git clone YOUR_GITHUB_REPO_URL apex-coach
cp -r apex-final/* apex-coach/
cd apex-coach
git add .
git commit -m "Initial APEX deploy"
git push
```

> Or just drag all these files into the GitHub repo using the website's upload button.

---

### Step 2 — Deploy on Vercel

1. Go to **vercel.com** → Sign up with GitHub
2. Click **"Add New Project"** → Import your `apex-coach` repo
3. Framework: **Next.js** (auto-detected)
4. Click **"Environment Variables"** and add these:

| Name | Value |
|------|-------|
| `WHOOP_CLIENT_ID` | `1bb7be2c-d532-4bb5-b11e-18a83612e66d` |
| `WHOOP_CLIENT_SECRET` | `393c10755fb3883f7767eed4b25758d2c2b5c23015309bc13f4e1563adb16b38` |
| `WHOOP_REDIRECT_URI` | `https://YOUR-APP-NAME.vercel.app/api/whoop/callback` |
| `ANTHROPIC_API_KEY` | Your Claude API key from console.anthropic.com |
| `CANVAS_TOKEN` | Your Canvas token (optional — can also enter in app) |

5. Click **Deploy** → wait ~2 minutes

---

### Step 3 — Update WHOOP Redirect URI

1. Copy your Vercel URL (e.g. `https://apex-coach-abc123.vercel.app`)
2. Go to **developer.whoop.com** → your app → Edit
3. Update Redirect URI to: `https://YOUR-VERCEL-URL.vercel.app/api/whoop/callback`
4. Back in Vercel → Environment Variables → update `WHOOP_REDIRECT_URI` to match
5. Vercel → Deployments → Redeploy

---

### Step 4 — Connect Everything

1. Open your Vercel URL
2. Click **"Connect WHOOP"** in the top bar or Settings → logs in with 1 click
3. Click **"Connect Canvas"** → paste your Canvas token from canvas.osu.edu
4. OSU Dining loads automatically
5. Apple Health → go to Recovery page → enter data manually (or use Health Auto Export app)

---

## Canvas Token

1. Go to **canvas.osu.edu**
2. Click your profile photo → **Account** → **Settings**
3. Scroll to **Approved Integrations** → **New Access Token**
4. Name: `APEX`, no expiration
5. Copy the token and paste it in Settings within the app

## Anthropic API Key

1. Go to **console.anthropic.com**
2. Sign up free → **API Keys** → **Create Key**
3. Paste into Vercel environment variables as `ANTHROPIC_API_KEY`

---

## Privacy

Your WHOOP and Canvas tokens are stored in **HttpOnly cookies** — never accessible to JavaScript or visible in the browser. No health data is stored in any database. See `APEX_Privacy_Policy.docx` for the full policy.
