// pages/api/canvas/data.js
// Proxies Canvas LMS requests using a stored token

function parseCookies(req) {
  return Object.fromEntries(
    (req.headers.cookie || '').split(';')
      .filter(Boolean)
      .map(c => c.trim().split('=').map(s => decodeURIComponent(s.trim())))
  );
}

async function canvasGet(path, token) {
  const r = await fetch(`https://osu.instructure.com/api/v1${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!r.ok) throw new Error(`Canvas ${r.status} on ${path}`);
  return r.json();
}

export default async function handler(req, res) {
  // POST = save token
  if (req.method === 'POST') {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    if (!body?.token) return res.status(400).json({ error: 'No token provided' });

    const isProd = process.env.NODE_ENV === 'production';
    res.setHeader('Set-Cookie',
      `canvas_token=${body.token}; Path=/; HttpOnly; SameSite=Lax${isProd ? '; Secure' : ''}; Max-Age=31536000`
    );
    return res.status(200).json({ saved: true });
  }

  // DELETE = remove token
  if (req.method === 'DELETE') {
    res.setHeader('Set-Cookie', 'canvas_token=; Path=/; Max-Age=0; HttpOnly');
    return res.status(200).json({ disconnected: true });
  }

  // GET = fetch canvas data
  const cookies = parseCookies(req);
  const token = cookies.canvas_token || process.env.CANVAS_TOKEN;

  if (!token) return res.status(401).json({ error: 'not_connected' });

  try {
    const [courses, todos] = await Promise.all([
      canvasGet('/courses?enrollment_state=active&per_page=10&include[]=term', token),
      canvasGet('/users/self/todo?per_page=20', token),
    ]);

    const activeCourses = courses.filter(c => !c.access_restricted_by_date);

    const assignmentArrays = await Promise.all(
      activeCourses.slice(0, 8).map(c =>
        canvasGet(`/courses/${c.id}/assignments?order_by=due_at&per_page=10&bucket=upcoming`, token)
          .then(arr => arr.map(a => ({ ...a, courseName: c.name, courseCode: c.course_code })))
          .catch(() => [])
      )
    );

    const now = new Date();
    const assignments = assignmentArrays
      .flat()
      .filter(a => a.due_at && new Date(a.due_at) > now)
      .sort((a, b) => new Date(a.due_at) - new Date(b.due_at))
      .slice(0, 20)
      .map(a => {
        const due = new Date(a.due_at);
        const diffMs = due - now;
        const diffDays = Math.ceil(diffMs / 86400000);
        return {
          id:         a.id,
          name:       a.name,
          course:     a.courseName,
          courseCode: a.courseCode,
          dueAt:      a.due_at,
          dueIn:      diffDays === 0 ? 'Today' : diffDays === 1 ? 'Tomorrow' : `${diffDays} days`,
          urgent:     diffDays <= 2,
          points:     a.points_possible,
          url:        a.html_url,
          submitted:  a.has_submitted_submissions,
        };
      });

    return res.status(200).json({
      connected: true,
      courses: activeCourses.map(c => ({ id: c.id, name: c.name, code: c.course_code })),
      assignments,
      todoCount: todos.length,
    });

  } catch (err) {
    console.error('Canvas error:', err.message);
    if (err.message.includes('401')) {
      return res.status(401).json({ error: 'invalid_token' });
    }
    return res.status(500).json({ error: err.message });
  }
}
