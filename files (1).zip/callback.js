// pages/api/whoop/callback.js
// WHOOP redirects here after user logs in and approves the app

export default async function handler(req, res) {
  const { code, error } = req.query;

  if (error || !code) {
    return res.redirect('/?error=whoop_denied');
  }

  const clientId     = process.env.WHOOP_CLIENT_ID;
  const clientSecret = process.env.WHOOP_CLIENT_SECRET;
  const redirectUri  = process.env.WHOOP_REDIRECT_URI;

  try {
    const tokenRes = await fetch('https://api.prod.whoop.com/oauth/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type:    'authorization_code',
        code,
        client_id:     clientId,
        client_secret: clientSecret,
        redirect_uri:  redirectUri,
      }),
    });

    const data = await tokenRes.json();

    if (!tokenRes.ok || !data.access_token) {
      console.error('WHOOP token exchange failed:', data);
      return res.redirect('/?error=whoop_token_failed');
    }

    const isProd = process.env.NODE_ENV === 'production';
    const secure = isProd ? '; Secure' : '';
    const maxAge = 60 * 60 * 24 * 30; // 30 days

    res.setHeader('Set-Cookie', [
      `whoop_access=${data.access_token}; Path=/; HttpOnly; SameSite=Lax${secure}; Max-Age=${data.expires_in || 3600}`,
      `whoop_refresh=${data.refresh_token}; Path=/; HttpOnly; SameSite=Lax${secure}; Max-Age=${maxAge}`,
    ]);

    return res.redirect('/?connected=whoop');
  } catch (err) {
    console.error('WHOOP callback error:', err);
    return res.redirect('/?error=whoop_server_error');
  }
}
