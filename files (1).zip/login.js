// pages/api/whoop/login.js
// Redirects user to WHOOP's OAuth authorization page

export default function handler(req, res) {
  const clientId   = process.env.WHOOP_CLIENT_ID;
  const redirectUri = process.env.WHOOP_REDIRECT_URI;

  const scopes = [
    'read:recovery',
    'read:sleep',
    'read:workout',
    'read:cycles',
    'read:body_measurement',
    'read:profile',
  ].join(' ');

  const params = new URLSearchParams({
    response_type: 'code',
    client_id:     clientId,
    redirect_uri:  redirectUri,
    scope:         scopes,
    state:         'apex_auth',
  });

  const authUrl = `https://api.prod.whoop.com/oauth/oauth2/auth?${params}`;
  res.redirect(authUrl);
}
