// pages/api/whoop/disconnect.js
export default function handler(req, res) {
  res.setHeader('Set-Cookie', [
    'whoop_access=; Path=/; Max-Age=0; HttpOnly',
    'whoop_refresh=; Path=/; Max-Age=0; HttpOnly',
  ]);
  res.redirect('/');
}
