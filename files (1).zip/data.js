// pages/api/whoop/data.js
// Fetches live WHOOP data - recovery, sleep, strain, profile

function parseCookies(req) {
  return Object.fromEntries(
    (req.headers.cookie || '').split(';')
      .filter(Boolean)
      .map(c => c.trim().split('=').map(s => decodeURIComponent(s.trim())))
  );
}

async function refreshAccessToken(refreshToken) {
  const r = await fetch('https://api.prod.whoop.com/oauth/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type:    'refresh_token',
      refresh_token: refreshToken,
      client_id:     process.env.WHOOP_CLIENT_ID,
      client_secret: process.env.WHOOP_CLIENT_SECRET,
    }),
  });
  return r.json();
}

async function whoopFetch(path, token) {
  const r = await fetch(`https://api.prod.whoop.com/developer/v1${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return { status: r.status, data: await r.json() };
}

export default async function handler(req, res) {
  const cookies = parseCookies(req);
  let accessToken  = cookies.whoop_access;
  const refreshTok = cookies.whoop_refresh;

  if (!accessToken && !refreshTok) {
    return res.status(401).json({ error: 'not_connected' });
  }

  // If no access token, try refreshing
  if (!accessToken && refreshTok) {
    const refreshed = await refreshAccessToken(refreshTok);
    if (!refreshed.access_token) {
      return res.status(401).json({ error: 'session_expired' });
    }
    accessToken = refreshed.access_token;
    const isProd = process.env.NODE_ENV === 'production';
    res.setHeader('Set-Cookie',
      `whoop_access=${accessToken}; Path=/; HttpOnly; SameSite=Lax${isProd ? '; Secure' : ''}; Max-Age=${refreshed.expires_in || 3600}`
    );
  }

  try {
    // Fetch everything in parallel
    const [recovRes, sleepRes, cycleRes, profileRes, workoutRes] = await Promise.all([
      whoopFetch('/recovery?limit=1', accessToken),
      whoopFetch('/activity/sleep?limit=1', accessToken),
      whoopFetch('/cycle?limit=1', accessToken),
      whoopFetch('/user/profile/basic', accessToken),
      whoopFetch('/activity/workout?limit=5', accessToken),
    ]);

    // Handle expired token mid-request
    if (recovRes.status === 401) {
      if (!refreshTok) return res.status(401).json({ error: 'session_expired' });
      const refreshed = await refreshAccessToken(refreshTok);
      if (!refreshed.access_token) return res.status(401).json({ error: 'refresh_failed' });
      // Set new cookie and tell client to retry
      const isProd = process.env.NODE_ENV === 'production';
      res.setHeader('Set-Cookie',
        `whoop_access=${refreshed.access_token}; Path=/; HttpOnly; SameSite=Lax${isProd ? '; Secure' : ''}; Max-Age=${refreshed.expires_in || 3600}`
      );
      return res.status(401).json({ error: 'token_refreshed_retry' });
    }

    const recovery = recovRes.data?.records?.[0];
    const sleep    = sleepRes.data?.records?.[0];
    const cycle    = cycleRes.data?.records?.[0];
    const profile  = profileRes.data;
    const workouts = workoutRes.data?.records || [];

    // Helper: ms to "Xh Ym"
    const msToHM = ms => {
      if (!ms) return '0h 0m';
      const h = Math.floor(ms / 3600000);
      const m = Math.round((ms % 3600000) / 60000);
      return `${h}h ${m}m`;
    };

    return res.status(200).json({
      connected: true,
      profile: {
        firstName: profile?.first_name || 'Athlete',
        lastName:  profile?.last_name  || '',
        email:     profile?.email      || '',
      },
      recovery: {
        score:       Math.round(recovery?.score?.recovery_score         ?? 0),
        hrv:         Math.round(recovery?.score?.hrv_rmssd_milli        ?? 0),
        restingHr:   Math.round(recovery?.score?.resting_heart_rate     ?? 0),
        skinTempF:   recovery?.score?.skin_temp_celsius
          ? ((recovery.score.skin_temp_celsius * 9/5) + 32).toFixed(1)
          : null,
        spo2:        recovery?.score?.spo2_percentage
          ? Math.round(recovery.score.spo2_percentage) : null,
        // Green ≥ 67, Yellow 34–66, Red ≤ 33
        level: (recovery?.score?.recovery_score ?? 0) >= 67 ? 'green'
             : (recovery?.score?.recovery_score ?? 0) >= 34 ? 'yellow' : 'red',
      },
      sleep: {
        totalMs:          sleep?.score?.stage_summary?.total_in_bed_time_milli           ?? 0,
        remMs:            sleep?.score?.stage_summary?.total_rem_sleep_time_milli        ?? 0,
        deepMs:           sleep?.score?.stage_summary?.total_slow_wave_sleep_time_milli  ?? 0,
        lightMs:          sleep?.score?.stage_summary?.total_light_sleep_time_milli      ?? 0,
        totalFormatted:   msToHM(sleep?.score?.stage_summary?.total_in_bed_time_milli    ?? 0),
        remFormatted:     msToHM(sleep?.score?.stage_summary?.total_rem_sleep_time_milli ?? 0),
        deepFormatted:    msToHM(sleep?.score?.stage_summary?.total_slow_wave_sleep_time_milli ?? 0),
        performancePct:   Math.round(sleep?.score?.sleep_performance_percentage ?? 0),
        efficiencyPct:    Math.round(sleep?.score?.sleep_efficiency_percentage  ?? 0),
        respiratoryRate:  sleep?.score?.respiratory_rate?.toFixed(1) ?? null,
        start:            sleep?.start ?? null,
        end:              sleep?.end   ?? null,
      },
      strain: {
        score:      cycle?.score?.strain?.toFixed(1)                   ?? null,
        avgHr:      cycle?.score?.average_heart_rate                   ?? null,
        maxHr:      cycle?.score?.max_heart_rate                       ?? null,
        kilojoules: cycle?.score?.kilojoule ? Math.round(cycle.score.kilojoule) : null,
        calsBurned: cycle?.score?.kilojoule ? Math.round(cycle.score.kilojoule * 0.239) : null,
      },
      recentWorkouts: workouts.slice(0, 5).map(w => ({
        sport:    w.sport_id,
        strain:   w.score?.strain?.toFixed(1) ?? null,
        avgHr:    w.score?.average_heart_rate ?? null,
        maxHr:    w.score?.max_heart_rate     ?? null,
        cals:     w.score?.kilojoule ? Math.round(w.score.kilojoule * 0.239) : null,
        start:    w.start,
        end:      w.end,
      })),
    });

  } catch (err) {
    console.error('WHOOP data error:', err);
    return res.status(500).json({ error: 'fetch_failed', message: err.message });
  }
}
